module Jekyll
  module MultipleLanguagesPlugin
    VERSION = "1.5.1"
  end
end

